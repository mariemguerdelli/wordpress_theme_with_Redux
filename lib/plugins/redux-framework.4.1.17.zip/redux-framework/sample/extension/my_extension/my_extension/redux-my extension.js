/* global jQuery, document */

/** Add any Javascript for your extension here.  Use of this file is optional and is only for those
 * who wish to output the file CSS using a SASS compiler.
 *
 * Please be sure to rename the 'my-extension' part of the file name to the name of your extension. Pleas use
 * dashes instead of underscores.
 */

$( document ).ready(
	function() {

	}
)( jQuery );
